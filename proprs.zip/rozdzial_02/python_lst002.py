﻿
print("Witaj, świecie!")
