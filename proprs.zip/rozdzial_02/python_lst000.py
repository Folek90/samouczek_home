﻿# Dziękuję za kupienie mojej książki. Możecie do mnie pisać na adres cory[at]theselftaughtprogrammer.io

print("Witaj, świecie!")
