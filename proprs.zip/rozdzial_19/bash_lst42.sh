
cd .. $ git clone [url_repozytorium]
