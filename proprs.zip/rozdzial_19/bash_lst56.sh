
$ git add -m "dodanie nowego pliku"
