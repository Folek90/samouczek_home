
$ git log
