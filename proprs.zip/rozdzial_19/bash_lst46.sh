
$ git add wisielec.py
