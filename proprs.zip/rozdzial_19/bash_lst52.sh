
$ git pull origin master
