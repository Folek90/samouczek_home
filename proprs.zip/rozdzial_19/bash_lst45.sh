
$ git status
