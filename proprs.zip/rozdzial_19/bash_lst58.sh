
$  git diff witaj_swiecie.py
