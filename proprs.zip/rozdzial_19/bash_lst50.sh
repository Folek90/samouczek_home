git commit -m "moja pierwsza rewizja"
$ git commit -m "moja pierwsza rewizja"
