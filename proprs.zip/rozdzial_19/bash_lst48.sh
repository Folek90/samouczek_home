
$ git reset hangman.py.
