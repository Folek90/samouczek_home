﻿
if not win:
    print("\n".join(stages[0: wrong]))
    print("Przegrałeś! Miałeś odgadnąć: {}.".format(word))