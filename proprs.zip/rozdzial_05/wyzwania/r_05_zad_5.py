songs = {"John Lennon": "Stand by Me",
         "Kanye West": "Homecoming",
         "Swedish House Mafia": "Don't You Worry Child"
}
