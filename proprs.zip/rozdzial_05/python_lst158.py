﻿
eights = ["Edgar Allan Poe",
          "Charles Dickens"]


nines = ["Hemingway",
         "Fitzgerald",
         "Orwell"]


authors = (eights, nines)
print(authors)
