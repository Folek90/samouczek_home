
colors = ["niebieski","zielony","czerwony"]
"czarny" not in colors
