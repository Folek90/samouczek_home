﻿
colors = ["niebieski","zielony","czerwony"]
colors
item = colors.pop()
item
colors
