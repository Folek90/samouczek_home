﻿
# kontynulacja poprzedniego
# przykładu python_lst154.py

rap = lists[0]
print(rap)
