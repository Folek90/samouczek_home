
colors = ["niebieski","zielony","czerwony"]
"zielony" in colors
