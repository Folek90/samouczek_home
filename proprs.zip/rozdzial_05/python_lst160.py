﻿
ny = {"lokalizacja":
      (40.7128,
       74.0059),


      "celebryci":
      ["W. Allen",
       "Jay Z",
       "K. Bacon"],

      "fakty":
      {"stan":
       "NY",
       "kraj":
       "Ameryka"}
}
