
"Witaj".upper()
