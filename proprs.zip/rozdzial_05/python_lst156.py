
# kontynuacja poprzedniego
# przykładu: python_lst154.py


rap = lists[0]
rap.append("Kendrick Lamar")
print(rap)
print(lists)
