﻿
dys = ("1984",
        "Nowy wspaniały świat",
        "Fahrenheit 451")

"Folwark zwierzęcy" not in dys
