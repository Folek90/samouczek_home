
fruit = ["mango", "banan", "gruszka"]
fruit.append("pomelo")
fruit.append("figa")
fruit
