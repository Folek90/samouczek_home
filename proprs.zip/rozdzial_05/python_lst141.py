
# to jest krotka
("programista_samouk",)


# to nie jest krotka
(9) + 1
