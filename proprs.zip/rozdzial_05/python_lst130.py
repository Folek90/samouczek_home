﻿colors = ["niebieski","zielony","czerwony"]
colors[4]
