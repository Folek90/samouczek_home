
"Witaj".replace("j", "m")
