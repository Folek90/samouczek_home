﻿
colors = ["niebieski","zielony","czerwony"]
colors
colors[2] = "filetowy"
colors

print (colors)