﻿
facts = dict()

# dodanie wartości
facts["programowanie"] = "zabawa"
# pobranie wartości
facts["programowanie"]

# dodanie wartości
facts["Bill"] = "Gates"
# pobranie wartości
facts["Bill"]

# dodanie wartości
facts["Grunwald"] = 1410
# pobranie wartości
facts["Grunwald"]
