
books = {"Dracula": "Stoker",
         "1984": "Orwell",
         "Proces": "Kafka"}


del books["Proces"]

books
