
fruit = ["mango", "banan", "gruszka"]
