﻿
dys = ("1984",
        "Nowy wspaniały świat",
        "Fahrenheit 451")

dys[1] = "Folwark zwierzęcy"
