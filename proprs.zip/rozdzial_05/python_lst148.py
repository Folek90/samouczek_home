
fruits = {"agrest":
          "zielony",
          "porzeczka":
          "czerwony"}
fruits
