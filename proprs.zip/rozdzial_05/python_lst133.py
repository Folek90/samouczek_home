
colors1 = ["niebieski","zielony","czerwony"]
colors2 = ["fioletowy", "czarny", "purpurowy"]
colors1 + colors2
