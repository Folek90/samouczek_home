﻿
lists = []
rap = ["Kanye West",
       "Jay Z",
       "Eminem",
       "Nas"]


rock = ["Bob Dylan",
        "The Beatles",
        "Led Zeppelin"]


djs = ["Zeds Dead",
       "Tiesto"]


lists.append(rap)
lists.append(rock)
lists.append(djs)


print(lists)
