
len(colors)
