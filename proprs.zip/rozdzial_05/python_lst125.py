
fruit = ["mango", "banan", "gruszka"]
fruit
