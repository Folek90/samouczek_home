
bill = dict({"Bill Gates":
             "charytatywność"})


"Bill Doors" not in bill
