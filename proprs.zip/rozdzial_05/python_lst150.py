bill = dict({"Bill Gates":
             "charytatywność"})

"Bill Gates" in bill
