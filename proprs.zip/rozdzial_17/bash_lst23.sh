
$ grep piękny zen.txt
