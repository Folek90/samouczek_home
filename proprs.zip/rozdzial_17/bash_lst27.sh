
$ grep ^Jeśli zen.txt
