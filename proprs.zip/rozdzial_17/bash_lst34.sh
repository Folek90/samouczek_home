
$ echo __hej__jak__się__masz__? | grep -o __.*__
