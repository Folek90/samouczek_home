
$ echo __siemka__stary | grep -o __.*__
