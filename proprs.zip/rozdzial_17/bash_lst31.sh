
$ echo 123 i 34 witajcie | grep [[:digit:]]
