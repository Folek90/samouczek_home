
 $ grep Piękny zen.txt
