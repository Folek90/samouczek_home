
$ echo Dwa drwa a czar trwaa. | grep -o rwa*
