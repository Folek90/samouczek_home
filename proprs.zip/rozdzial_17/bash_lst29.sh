
$ echo Dwa drwa. | grep -i [dr]wa