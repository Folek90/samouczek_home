
$ echo Kocham $ | grep  \$
