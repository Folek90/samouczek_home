#!/usr/bin/env bash
grep Holendrem zen.txt