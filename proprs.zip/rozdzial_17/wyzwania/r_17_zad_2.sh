#!/usr/bin/env bash

echo Arizona: 479, 501, 870. California: 209, 213, 650. | grep [[:digit:]]
