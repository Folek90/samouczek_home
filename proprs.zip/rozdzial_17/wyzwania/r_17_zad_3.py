﻿import re

match = re.findall(".oo", "Bieg na orientację dookoła miejskiego zoo")
print(match)
