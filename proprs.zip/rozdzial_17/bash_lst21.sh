
$ export GREP_OPTIONS='--color=always'
$export GREP_OPTIONS='--color=always'

# albo z określeniem koloru

export GREP_OPTIONS='--color=always'
export GREP_COLOR='1;35;40'