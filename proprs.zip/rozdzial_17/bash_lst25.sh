
$ grep -o Piękny zen.txt
