
$ grep -i piękny zen.txt
