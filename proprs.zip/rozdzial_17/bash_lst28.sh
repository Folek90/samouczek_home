
$  grep nigdy.$ zen.txt
