a_queue = Queue()

for i in range(5):
    a_queue.enqueue(i)

print(a_queue.size())
