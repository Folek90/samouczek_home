
stack = Stack()
stack.push(1)
item = stack.pop()
print(item)
print(stack.is_empty())
