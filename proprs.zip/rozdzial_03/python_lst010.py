﻿
print("Siemka!")
