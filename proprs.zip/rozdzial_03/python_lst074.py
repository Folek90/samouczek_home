
x = 2
if x == 2:
    print("Liczba jest równa 2.")
if x % 2 == 0:
    print("Liczba jest parzysta.")
if x % 2 != 0:
    print("Liczba jest nieparzysta.")
