﻿
# To kod w języku JavaScript - nie będzie działać w Pythonie!

for (i = 0; i < 100; i++) {
    console.log("Witaj, świecie!");
}
