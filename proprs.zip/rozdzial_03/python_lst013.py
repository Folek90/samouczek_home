﻿
print\
("""To jest naprawdę bardzo, bardzo,
 bardzo długi wiersz kodu.""")
