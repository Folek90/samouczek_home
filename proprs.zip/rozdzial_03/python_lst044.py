
# liczba nieparzysta
11 % 2
