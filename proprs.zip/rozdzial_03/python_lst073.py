﻿
home = "Ameryka"
if home == "Ameryka":
    print("Witaj, Ameryko!")
