﻿# Ten kod zgłosi wyjątek.

y = 2
         x = 1
