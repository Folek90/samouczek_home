﻿# Nie uruchamiać.

int a;
a = 144;
