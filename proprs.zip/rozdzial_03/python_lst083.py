
print("Michael")






print("Jordan")
