﻿# python_lst004.py

for i in range(100):
    print("Witaj, świecie!")
