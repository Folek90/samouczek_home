﻿
x = 10
y = 10
z = x + y
z
a = x - y
a
