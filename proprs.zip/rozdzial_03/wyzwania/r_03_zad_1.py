﻿print("Dalej")
print("i wciąż")
print("do przodu!")
