﻿x = 2

if x <= 10:
    print("x jest mniejsze lub równe 10.")
elif x <= 25:
    print("x jest większe od 10, lecz mniejsze lub równe 25.")
else:
    print("x jest większe od 25.")
