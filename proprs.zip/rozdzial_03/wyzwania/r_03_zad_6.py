﻿age = 64
retirement = age - 65

if retirement < 10:
    print("Już niedługo przejdziesz na emeryturę.")
else:
    print("Jeszcze sporo czasu do emerytury!")
