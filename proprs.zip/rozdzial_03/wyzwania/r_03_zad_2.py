﻿x = 11
if x < 10:
    print("x jest mniejsze od 10.")
else:
    print("x jest większe lub równe 10")
