
home = "Kanada"
if home == "Ameryka":
    print("Witaj, Ameryko!")
else:
    print("Witaj, świecie!")
