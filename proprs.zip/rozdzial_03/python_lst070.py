
# Proszę tego nie wykonywać!

If (wyrażenie) Then
            (blok_kodu_1)
Else
            (blok_kodu_2)
