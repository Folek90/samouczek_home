﻿
home = "Mars"
if home == "Ameryka":
    print("Witaj, Ameryko!")
elif home == "Canada":
    print("Witaj, Kanado!")
elif home == "Thailand":
    print("Witaj, Tajlandio!")
elif home == "Mexico":
    print("Witaj, Meksyku!")
else:
    print("Witaj, świecie!")
