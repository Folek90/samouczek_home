﻿
# To jest komentarz
print("Witaj, świecie!")
