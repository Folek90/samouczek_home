﻿
# Komentarz
print("Witaj, świecie!")
