﻿
'Witaj, świecie!'
