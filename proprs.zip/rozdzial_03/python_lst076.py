﻿
home = "Tajlandia"
if home == "Japionia":
    print("Witaj, Japonio!")
elif home == "Tajlandia":
    print("Witaj, Tajlandio!")
elif home == "India":
    print("Witajcie, Indie!")
elif home == "China":
    print("Witajcie, Chiny!")
else:
    print("Witaj, świecie!")
