﻿# Ten kod jest nieprawidłowy!

my_string = "Witaj, świecie!
