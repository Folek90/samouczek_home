﻿
"Witaj, świecie!"
