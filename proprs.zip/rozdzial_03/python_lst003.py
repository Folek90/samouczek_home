
for i in range(100):
    print("Witaj, świecie!")
