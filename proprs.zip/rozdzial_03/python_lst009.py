﻿
print("Python")
