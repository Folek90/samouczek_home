﻿
# print Witaj, świecie!
print("Witaj, świecie!")
