
print("Witaj, świecie!")
