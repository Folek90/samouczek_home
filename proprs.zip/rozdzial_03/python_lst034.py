﻿
hi = "Witaj, świecie!"
