﻿# Ten kod zgłasza wyjątek.

10 / 0
