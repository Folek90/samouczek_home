
# liczba parzysta
12 % 2
