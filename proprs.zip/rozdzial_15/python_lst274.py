
card1 = Card(10, 2)
card2 = Card(11, 3)
print(card1 > card2)
