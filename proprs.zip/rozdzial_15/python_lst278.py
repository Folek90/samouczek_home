
class Player:
   def __init__(self, name):
       self.wins = 0
       self.card = None
       self.name = name
