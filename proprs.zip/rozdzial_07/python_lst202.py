﻿
coms = ("Programowanie",
        "Znajomi",
        "Chillout")
for show in coms:
    print(show)
