﻿
while True:
    print("Witaj, świecie!")


