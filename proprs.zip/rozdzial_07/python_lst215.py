﻿
for i in range(1, 3):
    print(i)
    for letter in ["a", "b", "c"]:
        print(letter)
