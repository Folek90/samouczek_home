﻿
for i in range(1, 6):
    if i == 3:
        continue
    print(i)
