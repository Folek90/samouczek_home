﻿
shows = ["Jaka to melodia",
         "Spadkobiercy",
         "Familiada"]

for show in shows:
    print(show)
