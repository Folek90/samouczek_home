﻿
people = {"Fowler":
          "Wzorce projektowe",
          "Knuth":
          "Algorytny",
          "Stroustrup":
          "C++"
          }

for character in people:
    print(character)
