
for i in range(1, 11):
    print(i)
