﻿shows = ["Noc żywych trupów", "Ekipa", "Rodzina Soprano", "Pamiętniki wampirów"]
for index, show in enumerate(shows):
    print(index)
    print(show)
