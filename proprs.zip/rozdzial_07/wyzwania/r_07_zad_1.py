﻿shows = ["Noc żywych trupów", "Ekipa", "Rodzina Soprano", "Pamiętniki wampirów"]
for show in shows:
    print(show)
    