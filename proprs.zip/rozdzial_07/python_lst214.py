﻿
i = 1
while i <= 5:
    if i == 3:
        i += 1
        continue
    print(i)
    i += 1
