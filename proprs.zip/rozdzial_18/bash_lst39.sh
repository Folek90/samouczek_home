
pip freeze
