# kod modułu module2
import module1
