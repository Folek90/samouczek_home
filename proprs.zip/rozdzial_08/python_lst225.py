﻿
# kod modułu module1
print("Witaj!")
