
import hello

hello.print_hello()
