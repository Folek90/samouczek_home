
# http://tinyurl.com/jhtgxjn


def print_hello():
    print("Witaj")
