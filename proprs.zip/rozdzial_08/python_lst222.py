﻿
import keyword


keyword.iskeyword("for")
keyword.iskeyword("football")


