﻿# python_lst224.py

import hello

hello.print_hello()