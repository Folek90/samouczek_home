# python_lst223.py

def print_hello():
    print("Witaj")
