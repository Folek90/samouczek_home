import cubed

result = cubed.cube_it(3)
print(result)

