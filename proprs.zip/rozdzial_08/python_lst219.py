
import math


math.pow(2, 3)
