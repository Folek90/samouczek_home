﻿
import statistics

# średnia
nums = [1, 5, 33, 12, 46, 33, 2]
statistics.mean(nums)


# mediana
statistics.median(nums)


# dominanta
statistics.mode(nums)

