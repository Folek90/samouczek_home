
# Wynik może być inny niż 52,
# w końcu to ma być liczba losowa!

import random

random.randint(0,100)
