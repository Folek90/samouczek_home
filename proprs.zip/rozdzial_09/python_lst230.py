﻿
st = open("st.txt", "w")
st.write("Cześć... zapisano z Pythona!")
st.close()
