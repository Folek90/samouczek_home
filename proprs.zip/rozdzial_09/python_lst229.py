﻿
import os

os.path.join("Users",
             "bob",
             "st.txt")
