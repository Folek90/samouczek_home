﻿
# upewnij się, aby wykonać
# poprzedni przykład, by 
# utworzyć używany tu plik.

with open("st.txt", "r") as f:
    print(f.read())
