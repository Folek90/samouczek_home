﻿
bottles_of_beer(bob)
