﻿if bob < 1:
    print("""Nie ma już butelek
             piwa na ścianie. 
             Nie ma już butelek piwa.""")
    return
