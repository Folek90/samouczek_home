
$ mkdir tstp
