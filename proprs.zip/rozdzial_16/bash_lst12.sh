
$ cd ..
