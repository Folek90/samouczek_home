#!/bin/bash
cd /Users/coryalthoff
cd Users/coryalthoff
