#!/bin/bash
# Dodaj kolejny wiersz do swojego pliku .profile
export python_projects=~
cd $python_projects
