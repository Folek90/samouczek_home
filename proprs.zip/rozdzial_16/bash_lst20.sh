
$ echo $x
