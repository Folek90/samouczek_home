
$ cd /
