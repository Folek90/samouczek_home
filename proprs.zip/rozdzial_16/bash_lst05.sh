
$ pwd
