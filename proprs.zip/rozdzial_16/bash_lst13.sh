
$ rmdir tstp
