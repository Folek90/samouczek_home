
$ cd tstp
