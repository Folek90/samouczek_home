
$ history
