
$ touch .prog_samouk
