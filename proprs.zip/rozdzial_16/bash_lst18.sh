
$ ls | less
