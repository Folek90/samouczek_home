
$ echo Witaj, świecie!
