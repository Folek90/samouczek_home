
"imperialny".index("r")
