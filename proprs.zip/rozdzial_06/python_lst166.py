﻿
ff = "F. Fitzgerald"
ff = "F. Scott Fitzgerald"
ff
