
"Odpowiedziała mu: \"Owszem.\""
