
"William {}".format("Faulkner")
