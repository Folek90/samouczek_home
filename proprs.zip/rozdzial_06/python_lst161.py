﻿
""" wiersz pierwszy
    wiersz drugi
    wiersz trzeci
"""
