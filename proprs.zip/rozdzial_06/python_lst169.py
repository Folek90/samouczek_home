﻿
"Puchatek" * 3
