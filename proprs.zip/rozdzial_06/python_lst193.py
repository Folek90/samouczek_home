
'Odpowiedziała mu: "Owszem."'