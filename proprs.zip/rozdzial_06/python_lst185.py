﻿
try:
    "imperialny".index("z")
except:
    print("Nie znaleziono znaku.")
