
"Odpowiedziała mu: 'Owszem.'"