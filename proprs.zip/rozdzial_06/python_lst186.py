
"Kot" in "Kot w butach."
