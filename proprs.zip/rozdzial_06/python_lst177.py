﻿
"""Hej.Siema!""".split(".")