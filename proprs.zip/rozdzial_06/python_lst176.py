﻿
n1 = input("Wpisz rzeczownik: ")
v = input("Wpisz czasownik: ")
adj = input("Wpisz przymiotnik: ")
n2 = input("Wpisz rzeczownik: ")

r = """{} {} {} {}
    """.format(n1,
               v,
               adj,
               n2)

print(r)
