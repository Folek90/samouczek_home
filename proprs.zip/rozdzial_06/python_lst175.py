﻿
author = "William Faulkner"
year_born = "1897"

"""{} urodził się w {} roku."""\
   .format(author,
           year_born)