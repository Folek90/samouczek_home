
"trzech muszkieterów i...".capitalize()
