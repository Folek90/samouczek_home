
words = ["Zwinny",
         "lis",
         "przeskoczy",
         "nad",
         "leniwym",
         "psem",
         "."]
one_string = " ".join(words)
one_string
