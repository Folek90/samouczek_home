﻿
"Kot " + " w" + " butach"
