﻿
fict = ["Clavel",
        "Camus",
        "Orwell",
        "Huxley",
        "Austin"]
fict[0:3]
