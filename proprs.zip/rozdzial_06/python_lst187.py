﻿
"Kat" in "Kot w butach."