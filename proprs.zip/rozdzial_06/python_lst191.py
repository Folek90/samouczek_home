
'Odpowiedziała mu: \"Owszem.\"'
