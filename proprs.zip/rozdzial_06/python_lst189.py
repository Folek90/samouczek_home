
# Ten kod nie działa!

"Odpowiedziała mu: "Owszem.""
