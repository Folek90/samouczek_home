﻿
"TAK TO JEST.".lower()
