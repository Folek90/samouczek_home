﻿
print("wiersz1\nwiersz2\nwiersz3")

