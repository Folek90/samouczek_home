﻿
words = ["Zwinny",
         "lis",
         "przeskoczy",
         "nad",
         "leniwym",
         "psem",
         "."]
one = "".join(words)
one
