﻿
first_three = "abc"
result = "+".join(first_three)
result
