﻿
"Nie pytaj komu bije dzwon".upper()
