﻿
"kot" + "w" + "butach"
