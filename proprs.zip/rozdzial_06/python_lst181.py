﻿
s = "    To        "
s = s.strip()
s
