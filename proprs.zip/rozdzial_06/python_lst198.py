
ivan = """A żyć tak na skraju zguby \
trzeba samotnie"""

ivan[26:]