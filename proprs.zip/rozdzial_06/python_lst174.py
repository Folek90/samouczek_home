﻿
last = "Faulkner"
"William {}".format(last)
