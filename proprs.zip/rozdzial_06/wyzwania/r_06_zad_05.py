﻿fox = ["Zwinny", "lis", "przeskoczył", "nad", "leniwym", "psem", "."]
fox = " ".join(fox)
fox = fox[0: -2] + "."
print(fox)
