﻿sentence = "Długo na szturm i szaniec poglądał w milczeniu. Na koniec rzekł; 'Stracona'."
slce = sentence[0:49]
print(slce)
