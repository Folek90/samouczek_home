first_index = "Hemingway".index("m")
print(first_index)
