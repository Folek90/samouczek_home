﻿concat = "trzy" + "trzy" + "trzy"
mult = "trzy" * 3

print(concat)
print(mult)
