answer1 = input("Co wczoraj napisałeś?")
answer2 = input("Do kogo to wysłałeś?")

new_string = "Wczoraj napisałem {} i wysłałem do {}.".format(answer1, answer2)

print(new_string)
