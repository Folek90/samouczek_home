quote1 = "Na litość boską, królowo – zachrypiał – czy ośmieliłbym się nalać damie wódki? To czysty spirytus."
quote2 = "Kto szuka, ten najczęściej coś znajduje, niestety czasem zgoła nie to, czego mu potrzeba."
quote3 = "Jeśli ktoś stracił pieniądze nic nie stracił. Jeśli ktoś przegrał bitwę i stracił wojsko mało stracił. Jeśli ktoś stracił wiarę wszystko stracił."
