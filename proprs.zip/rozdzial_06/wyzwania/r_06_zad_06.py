﻿sentence = "W czasie suszy szosa sucha."
sentence = sentence.replace("s", "$")
print(sentence)
