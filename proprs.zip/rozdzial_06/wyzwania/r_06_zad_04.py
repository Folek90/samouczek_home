﻿lst = "Gdzie teraz? Kto teraz? Kiedy, teraz?".split("?")
print(lst)
