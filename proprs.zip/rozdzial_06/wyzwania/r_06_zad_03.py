x = "aldous Huxley urodził się w 1894 roku.".title()
print(x)
