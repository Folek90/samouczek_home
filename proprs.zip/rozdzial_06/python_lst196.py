
ivan = """A żyć tak na skraju zguby \
trzeba samotnie"""

ivan[0:10]
ivan[26:41]

