﻿
"imperialny".index("z")
