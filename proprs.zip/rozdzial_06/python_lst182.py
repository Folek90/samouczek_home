﻿
equ = "Ostry wicher mrozi."
equ = equ.replace("r", "@")
print(equ)
