﻿
type("Witaj, świecie!")
type(200)
type(200.1)
