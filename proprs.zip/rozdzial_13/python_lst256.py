﻿
print("Witaj, świecie!")
print(200)
print(200.1)
