
<!-- To jest komentarz w kozie HTML.
Zapisz ten plik pod nazwą index.html-->
<!-- bash_lst059.sh -->


<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Moja witryna</title>
</head>
<body>
     Witaj, świecie!
     <a href="https://www.google.com/">
     Kliknij tutaj</a>.
</body>
</html>
