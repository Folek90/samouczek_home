﻿
class Orange:
    def __init__(self, w, c):
        self.weight = w
        self.color = c
        print("Utworzono!")

or1 = Orange(380, "jasnopomarańczowy")
or2 = Orange(410, "ciemnopomarańczowy")
or3 = Orange(520, "żółty")
