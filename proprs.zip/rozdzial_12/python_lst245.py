﻿
class Orange:
    def __init__(self, w, c):
        self.weight = w
        self.color = c
        print("Utworzono!")