﻿
class Orange:
    def __init__(self, w, c):
        self.weight = w
        self.color = c
        print("Utworzono!")

or1 = Orange(410, "jasnopomarańczowy")
or1.weight = 650
or1.color = "ciemnopomarańczowy"

print(or1.weight)
print(or1.color)

