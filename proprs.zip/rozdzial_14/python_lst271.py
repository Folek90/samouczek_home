﻿
x = 10
if x is None:
    print("x jest równe None :( ")
else:
    print("x nie jest równe None")


x = None
if x is None:
    print("x jest równe None")
else:
    print("x jest równe None :( ")
