﻿
try:
    10 / 0
    c = "Nigdy nie zostanę zdefiniowana."
except ZeroDivisionError:
    print(c)
