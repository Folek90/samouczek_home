﻿# ciąg dalszy
# poprzedniego przykładu

f(2)
