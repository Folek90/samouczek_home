﻿
if x > 100:
    print("x jest > 100")
