﻿
def even_odd():
    n = input("wpisz liczbę: ")
    n = int(n)
    if n % 2 == 0:
        print("liczba jest parzysta.")
    else:
        print("liczba jest nieparzysta.")


even_odd()
even_odd()
even_odd()
