
len("Monty")
