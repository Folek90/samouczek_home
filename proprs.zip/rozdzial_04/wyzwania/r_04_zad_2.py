﻿def print_string(string):
    print(string)

print_string("Testujemy: 1, 2, 3.")
