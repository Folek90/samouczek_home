﻿
a = input("wpisz liczbę: ")
b = input("wpisz drugą liczbę: ")
a = int(a)
b = int(b)
print(a / b)
