﻿
def add(x, y):
    """
    Zwraca x + y.
    :param x: int.
    :param y: int.
    :return: int suma x i y.
    """
    return x + y
