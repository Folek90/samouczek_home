﻿
print(100)
