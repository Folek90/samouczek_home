# Nie próbuj tego wykonywać!

def [nazwa_funkcji]([parameters]):
    [definicja_funkcji]
