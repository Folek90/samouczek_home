﻿# ciąg dalszy
# poprzedniego przykładu

result = f(2)
print(result)
