
float(100)
