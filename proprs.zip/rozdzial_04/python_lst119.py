﻿
x = 100
print(x)
