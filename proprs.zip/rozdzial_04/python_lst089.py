﻿
def f(x):
    return x + 1


z = f(4)


if z == 5:
    print("z jest równe 5")
else:
    print("z nie jest równe 5")
