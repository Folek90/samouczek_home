﻿x = 100


def f():
    global x
    x += 1
    print(x)


f()
