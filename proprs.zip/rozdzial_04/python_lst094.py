
len("Python")
