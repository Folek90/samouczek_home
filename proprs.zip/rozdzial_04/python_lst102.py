﻿
n = input("wpisz liczbę: ")
n = int(n)


if n % 2 == 0:
    print("liczba jest parzysta.")
else:
    print("liczba jest nieparzysta.")


n = input("wpisz liczbę: ")
n = int(n)
if n % 2 == 0:
    print("liczba jest parzysta.")
else:
    print("liczba jest nieparzysta.")


n = input("wpisz liczbę: ")
n = int(n)
if n % 2 == 0:
    print("liczba jest parzysta.")
else:
    print("liczba jest nieparzysta.")
