﻿age = input("Ile masz lat:")
int_age = int(age)
if int_age < 21:
    print("Jesteś młody!")
else:
    print("Rany... aleś ty stary!")
