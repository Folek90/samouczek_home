# Nie próbuj tego wykonywać!
f(x) = x * 2
